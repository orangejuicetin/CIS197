/*eslint-env browser */
/*globals $ */

// Default size of map (in tiles)
var DEFAULT_WIDTH = 30;
var DEFAULT_HEIGHT = 15;

var MapBuilder = function ($container, params) {
  MapBuilder.prototype.$palette = $container.find('.palette');
  MapBuilder.prototype.$map = $container.find('.map');
  if (params) {
    this.width = params.width;
    this.height = params.height;
  } else {
    this.width = DEFAULT_WIDTH; ``
    this.height = DEFAULT_HEIGHT;
  }
};

// TODO: Implement MapBuilder.setupPalette()
MapBuilder.prototype.setupPalette = function () {
  this.$palette.click(function (event) {
    MapBuilder.prototype.$currElement = event.target;
    $(this).addClass('selected');
    console.log(this.$palette);
  })
};


// TODO: Implement MapBuilder.setupMapCanvas
MapBuilder.prototype.setupMapCanvas = function () {
  console.log('working');
}

