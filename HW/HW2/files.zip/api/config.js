module.exports = {
  apiKey: 'CQAvTKqfHE1e33zTJOxQ0jFOE9tRKlok'
}
